package quantum.com.Melody.controllers;

import java.io.IOException;
import java.util.List;
import org.bson.json.JsonParseException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.var;
import quantum.com.Melody.entities.Son;
import quantum.com.Melody.enumerations.EnumFileType;
import quantum.com.Melody.exceptions.AlbumNotFoundException;
import quantum.com.Melody.exceptions.EnumarationException;
import quantum.com.Melody.exceptions.ProviderFileException;
import quantum.com.Melody.exceptions.SonNotFoundException;
import quantum.com.Melody.exceptions.UserNotFoundException;
import quantum.com.Melody.payloads.in.ModifSonPayload;
import quantum.com.Melody.payloads.out.ResponseData;
import quantum.com.Melody.services.AtlasSearch;
import quantum.com.Melody.services.SonServices;
@RestController
@AllArgsConstructor
@RequestMapping(value = "/son")
public class SonController {
  private final SonServices sonServices;
  private final AtlasSearch atlasSearch;

   @PostMapping(value = "/uploader_son",
    consumes = {MediaType.APPLICATION_JSON_VALUE,MediaType.MULTIPART_FORM_DATA_VALUE})
    public ResponseEntity<ResponseData> uploaderSon(String sonPayload, EnumFileType enumFileType,@RequestParam("file") MultipartFile file) 
    throws IOException,
        ProviderFileException,
          EnumarationException, JsonParseException, AlbumNotFoundException, UserNotFoundException{ 
            System.out.println(sonPayload);
          ResponseData responseData = sonServices.uploaderSon(sonPayload, file, enumFileType);
        return new ResponseEntity<ResponseData>(new ResponseData(200,"fichier Uploader avec Succes" , responseData),HttpStatus.CREATED);
    }

    @GetMapping(value = "/rechercher/{text}")
    public List<Son>rechercher(@PathVariable String text)throws SonNotFoundException{
      return atlasSearch.searchSon(text);
    }

    @GetMapping(value = "/listerTousLesSons")
    public ResponseEntity<List<Son>>listerAllSon()throws SonNotFoundException{
      return ResponseEntity.ok(sonServices.listerTousLesSons());
    }

    @GetMapping(value = "/findOneSonById")
    public ResponseEntity<Son>findOneSon(String idSon)throws SonNotFoundException{
      return ResponseEntity.ok(sonServices.findOneSon(idSon));
    }
    
    @DeleteMapping(value = "/supprimerSonById")
    public ResponseEntity<String> supprimerSon(String idSon) throws SonNotFoundException, AlbumNotFoundException{
      var son = sonServices.deleteSonByid(idSon);
      return new ResponseEntity<String>(son,HttpStatus.ACCEPTED);
    }

    @PutMapping(value = "/act_desact_sonById")
    public ResponseEntity<Son> act_desact_son(String idSon) throws SonNotFoundException{
      var son = sonServices.changerStatutSon(idSon);
      return new ResponseEntity<Son>(son, HttpStatus.OK);
    }

    @PutMapping(value = "modifSonById")
    public ResponseEntity<Son> modifSon(@Valid @RequestBody ModifSonPayload modifSonPayload, String idSon) throws SonNotFoundException, AlbumNotFoundException{
      var son = sonServices.modifSon(idSon, modifSonPayload);
      return new ResponseEntity<Son>(son,HttpStatus.ACCEPTED);
    }

    @DeleteMapping(value = "/deleteAllSons")
    public ResponseEntity<String> deleteAllSons() throws SonNotFoundException{
        var sons = sonServices.deleteAllSon();
        return new ResponseEntity<String>(sons, HttpStatus.OK);
    }   
}
