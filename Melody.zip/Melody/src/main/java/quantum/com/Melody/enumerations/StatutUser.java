package quantum.com.Melody.enumerations;

public enum StatutUser {
    ACTIF,
    NON_ACTIF,
    AUTRE,
}
