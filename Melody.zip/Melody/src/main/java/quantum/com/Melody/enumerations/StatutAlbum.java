package quantum.com.Melody.enumerations;

public enum StatutAlbum {
    ACTIF,
    NON_ACTIF,
    AUTRE,
}
