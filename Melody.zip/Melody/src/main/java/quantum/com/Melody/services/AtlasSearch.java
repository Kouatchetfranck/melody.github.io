package quantum.com.Melody.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.convert.MongoConverter;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import quantum.com.Melody.entities.Son;
import quantum.com.Melody.exceptions.SonNotFoundException;
@Component
@Service
public class AtlasSearch {
    @Autowired
    MongoClient mongoClient;
    @Autowired
    MongoConverter converter;


    public List<Son> searchSon(String text)throws SonNotFoundException{
        List<Son> sons = new ArrayList<>();
        MongoDatabase database = mongoClient.getDatabase("DataBaseName");
        MongoCollection<Document> collection = database.getCollection("CollectionName");
        AggregateIterable<Document> result = collection.aggregate(Arrays.asList(new Document("$search", 
        new Document("index", "searchSon")
                .append("text", 
        new Document("query", text)
                    .append("path", 
        new Document("wildcard", "*"))))));
        result.forEach(doc -> sons.add(converter.read(Son.class,doc)));
        if (sons.toString()=="[]") {
            throw new SonNotFoundException(500,"aucun résultat ne corespond à votre recherche !!");
        } else {
            return sons;
        }
    }
    
}
