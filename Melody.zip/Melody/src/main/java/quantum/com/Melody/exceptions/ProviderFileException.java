package quantum.com.Melody.exceptions;

public class ProviderFileException extends Exception {
    public ProviderFileException(int code, String message){
        super(message);
    }
}
