package quantum.com.Melody.enumerations;

public enum EnumFileType {
    AUDIOS,
}
