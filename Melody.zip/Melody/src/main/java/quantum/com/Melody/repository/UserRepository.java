package quantum.com.Melody.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import quantum.com.Melody.entities.User;

public interface UserRepository extends MongoRepository<User, String> {

}
