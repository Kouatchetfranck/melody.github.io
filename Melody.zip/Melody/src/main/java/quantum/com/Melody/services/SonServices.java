package quantum.com.Melody.services;

import java.io.IOException;
import java.io.StringReader;
import java.time.LocalDateTime;
import java.util.List;


import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.internal.Streams;
import com.google.gson.stream.JsonReader;

import lombok.AllArgsConstructor;
import lombok.var;
import quantum.com.Melody.config.GlobalConfig;

import quantum.com.Melody.entities.Son;
import quantum.com.Melody.enumerations.EnumFileType;
import quantum.com.Melody.enumerations.StatutSon;
import quantum.com.Melody.exceptions.AlbumNotFoundException;
import quantum.com.Melody.exceptions.EnumarationException;
import quantum.com.Melody.exceptions.ProviderFileException;
import quantum.com.Melody.exceptions.SonNotFoundException;
import quantum.com.Melody.exceptions.UserNotFoundException;
import quantum.com.Melody.payloads.in.ModifSonPayload;
import quantum.com.Melody.payloads.in.SonPayload;
import quantum.com.Melody.payloads.out.ResponseData;
import quantum.com.Melody.payloads.out.ResponseFileService;
import quantum.com.Melody.repository.AlbumRepository;
import quantum.com.Melody.repository.SonRepository;
@AllArgsConstructor
@Service
public class SonServices {
    private final SonRepository sonRepository;
    private final AlbumServices albumServices;
    private final S3Service s3Service;
    private final AlbumRepository albumRepository;

    public ResponseData uploaderSon(String input, MultipartFile file, EnumFileType enumFileType)throws IOException, AlbumNotFoundException,
         ProviderFileException, JsonParseException, EnumarationException, UserNotFoundException{
            SonPayload sonPayload = converter(input);
        if(albumServices.checkAlbumExistByid(sonPayload.getIdAlbum())){
                if (enumFileType==EnumFileType.AUDIOS) {
                Son son = Son.builder()
                .enumFileType(EnumFileType.AUDIOS)
                .artiste(sonPayload.getArtiste())
                .dateUpload(LocalDateTime.now())
                .idAlbum(sonPayload.getIdAlbum())
                .titreSon(sonPayload.getTitreSon())
                .descriptionSon(sonPayload.getDescriptionSon())
                //.idUploader(sonPayload.getIdUploader())
                //.nomuploader(sonPayload.getNomuploader())
                .statutSon(StatutSon.ACTIF)
                .idAlbum(sonPayload.getIdAlbum())
                //.nomAlbum(sonPayload.getNomAlbum())
                .build();
                ResponseFileService responseFileService = s3Service.savefile(file, GlobalConfig.getPathFileType(enumFileType));
                if (responseFileService.getCode()==200) {
                    sonRepository.save(son);
                    son.setUrlSon(responseFileService.getMessage());
                    son.setNomAlbum(albumRepository.findById(sonPayload.getIdAlbum()).get().getTitreAlbum());
                    albumServices.addSon2Album(sonPayload.getIdAlbum(), son);
                    sonRepository.save(son);
                    return new ResponseData(200, "son enregistree avec success", son);
                } else {
                    throw new ProviderFileException(500,"impossible de se connecter au fournisseur d'accès");
                }
                } else {
                    throw new EnumarationException(500, "le type de fichier n'existe pas !!");
                } 
        }else{
            throw new AlbumNotFoundException(500, "l'album avec pour id : "+sonPayload.getIdAlbum()+" n'existe pas !!");
        }
    }

    public Son changerStatutSon(String id) throws SonNotFoundException{
        try {
            
            Boolean test = sonRepository.existsById(id);
            if (test) {
                Son son = sonRepository.findById(id).get();
                if (son.getStatutSon().equals(StatutSon.ACTIF)) {
                son.setStatutSon(StatutSon.NON_ACTIF);
            } else if (son.getStatutSon().equals(StatutSon.NON_ACTIF)) {
                son.setStatutSon(StatutSon.ACTIF);
            }
            return sonRepository.save(son);
            }
            else {
                throw new SonNotFoundException(500,"le son avec pour id : "+id+" n'existe pas !! ");
            }
        } catch (Exception e) {
            throw new SonNotFoundException(500,"erreur lors de l'essaie de désactivation du son !! avec pour id : "+id);
        }
    }

    public Son modifSon(String id, ModifSonPayload sonPayload)throws SonNotFoundException,AlbumNotFoundException{
        Boolean test = sonRepository.existsById(id);
        Boolean testAlb = albumRepository.existsById(sonPayload.getIdAlbum());
        if (test) {
            if (testAlb) {
                var son = sonRepository.findById(id).get();
                son.setDescriptionSon(sonPayload.getDescriptionSon());
                son.setArtiste(sonPayload.getArtiste());
                son.setIdAlbum(sonPayload.getIdAlbum());
                var album = albumRepository.findById(sonPayload.getIdAlbum()).get();
                son.setNomAlbum(album.getTitreAlbum());
                son.setTitreSon(sonPayload.getTitreSon());
                return sonRepository.save(son);
            } else {
                throw new AlbumNotFoundException(500,"l'album avec pour id : "+sonPayload.getIdAlbum()+" n'existe pas !! ");
            }
        } else {
            throw new SonNotFoundException(500,"le son avec pour id : "+id+" n'existe pas !! ");
        }
    }

    public List<Son>listerTousLesSons() throws SonNotFoundException{
         var liste = sonRepository.findAll();
         if (liste.toString()=="[]") {
            throw new SonNotFoundException(500,"aucun son trouvé !!");
         } else {
            return liste;
         }
    }

    public Son findOneSon(String idSon)throws SonNotFoundException{
        Boolean test = sonRepository.existsById(idSon);
         if (test) {
            var son = sonRepository.findById(idSon).get();
            return son;
         } else {
            throw new SonNotFoundException(500,"aucun son trouvé avec pour id : "+idSon);
         }
    }

    public boolean checkSonExistByid(String id) throws SonNotFoundException{
        try {
            return sonRepository.existsById(id);
        } catch (Exception e) {
            throw new SonNotFoundException(500,"le son avec pour id : "+id+" est inexistant !!");
        }   
    }

    public String deleteSonByid(String id) throws SonNotFoundException, AlbumNotFoundException{
        //Boolean test = sonRepository.existsById(id);
        Boolean test = sonRepository.existsById(id);
        //System.out.println("un");
        if (test) {
            Son son = sonRepository.findById(id).get();
            //System.out.println("deux");
            Boolean idAlbum = albumRepository.existsById(son.getIdAlbum());
            //System.out.println("troix");
            if (idAlbum) {
                albumServices.RemoveSon2Album(son.getIdAlbum(), son.getIdSon().toString());
            } else {
                try {
                    String fileName = son.getUrlSon();
                    System.out.println("url son :"+son.getUrlSon().toString());
                    String value = fileName.split("d1is7hz5o3oqax.cloudfront.net/")[-1];
                    System.out.println("value "+value);
                    sonRepository.deleteById(id);
                    //s3Service.deleteFile(value);
                } catch (Exception e) {
                    throw new SonNotFoundException(500,"l'url du son n'existe pas !!");
                }
            }
            //System.out.println("un");
            return "le son avec pour id : "+id+" a été supprimer !!";
        } else {
            throw new SonNotFoundException(500,"le son avec pour id : "+id+" est inexistant !!");
        }    
    }

    public SonPayload converter(String input) throws EnumarationException, JsonParseException{
        try {
            JsonObject jsonObject = Streams.parse(new JsonReader(new StringReader(input))).getAsJsonObject();
        SonPayload sonPayload = new SonPayload();
        String titreSon = jsonObject.get("titreSon").getAsString();
        String descriptionSon = jsonObject.get("descriptionSon").getAsString();
        String artiste = jsonObject.get("artiste").getAsString();
        String idAlbum = jsonObject.get("idAlbum").getAsString();
        sonPayload.setArtiste(artiste);
        sonPayload.setDescriptionSon(descriptionSon);
        sonPayload.setIdAlbum(idAlbum);
        sonPayload.setTitreSon(titreSon);
        return sonPayload;
        } catch (Exception e) {
            throw new JsonParseException("erreur lors de la procedure de cerialisation !!");
        }
    }

    public String deleteAllSon() throws SonNotFoundException{
        var sons = sonRepository.findAll();
    if (sons == null||sons.isEmpty()||sons.contains(null)) {
        throw new SonNotFoundException(500,"aucun son trouvé !!");
    } else {
        sonRepository.deleteAll();
        return "tous les sons ont été supprimés !! ";
    }
    }
    
}
