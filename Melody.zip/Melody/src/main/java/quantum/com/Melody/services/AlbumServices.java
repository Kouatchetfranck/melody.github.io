package quantum.com.Melody.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.var;
import quantum.com.Melody.entities.Album;
import quantum.com.Melody.entities.Son;
import quantum.com.Melody.enumerations.StatutAlbum;
import quantum.com.Melody.exceptions.AlbumNotFoundException;
import quantum.com.Melody.exceptions.SonNotFoundException;
import quantum.com.Melody.exceptions.UserNotFoundException;
import quantum.com.Melody.payloads.in.AlbumPayloads;
import quantum.com.Melody.payloads.in.ModifAlbumPayload;
import quantum.com.Melody.repository.AlbumRepository;
import quantum.com.Melody.repository.SonRepository;

@Data
@AllArgsConstructor
@Builder
@Service
public class AlbumServices {
    private UserServices userServices;
    private AlbumRepository albumRepository;
    private SonRepository sonRepository;

    public Album creeralbum(AlbumPayloads albumPayloads) throws AlbumNotFoundException,UserNotFoundException{
        try {
            Album album = Album.builder()
            .titreAlbum(albumPayloads.getTitreAlbum())
            .descriptionAlbum(albumPayloads.getDescriptionAlbum())
            //.idCreateur(albumPayloads.getIdCreateur())
            //.nomCreateur(albumPayloads.getNomCreateur())
            .statutAlbum(StatutAlbum.ACTIF)
            .artiste(albumPayloads.getArtiste())
            .dateCreationAlbum(LocalDate.now())
            .build();
            album.setNbrSons(0);
            return albumRepository.save(album);
        } catch (Exception e) {
            throw new UserNotFoundException(500,"id d'utilisateur inexistant !!");
        }
    }

    public Album changerStatutAlbum(String idAlbum)throws AlbumNotFoundException{
        Boolean test = albumRepository.existsById(idAlbum);
        if (test) {
            Album album = albumRepository.findById(idAlbum).get();
            if (album.getStatutAlbum().equals(StatutAlbum.ACTIF)) {
                album.setStatutAlbum(StatutAlbum.NON_ACTIF);
            } else if (album.getStatutAlbum().equals(StatutAlbum.NON_ACTIF)) {
                album.setStatutAlbum(StatutAlbum.ACTIF);   
            } 
                return albumRepository.save(album);
        }  
        else {
            throw new AlbumNotFoundException(500,"l'album avec pour id : "+idAlbum+" n'existe pas !! ");
        } 
    }

    public Album modifAlbum(String id, ModifAlbumPayload albumPayloads)throws AlbumNotFoundException{
        Boolean test = albumRepository.existsById(id);
        if (test) {
            Album album = albumRepository.findById(id).get();
            album.setTitreAlbum(albumPayloads.getTitreAlbum());
            album.setDescriptionAlbum(albumPayloads.getDescriptionAlbum());
            //album.setNomCreateur(albumPayloads.getNomCreateur());
            album.setArtiste(albumPayloads.getArtiste());
            return albumRepository.save(album);
        } else {
            throw new AlbumNotFoundException(500,"l'album avec pour id : "+id+" n'existe pas !! ");
        }
    }

    public List<Album>listertousLesAlbums()throws AlbumNotFoundException{
        var liste = albumRepository.findAll();
         if (liste.toString()=="[]") {
            throw new AlbumNotFoundException(500,"aucun album trouvé !!");
         } else {
            return liste;
         }
    }

    public Album findOneAlbum(String idAlbum)throws AlbumNotFoundException{
        Boolean test = albumRepository.existsById(idAlbum);
         if (test) {
            var album = albumRepository.findById(idAlbum).get();
            return album;
         } else {
            throw new AlbumNotFoundException(500,"aucun album trouvé avec pour id : "+idAlbum);
         }
    }

    public boolean checkAlbumExistByid(String id) throws AlbumNotFoundException{
        try {
            return albumRepository.existsById(id);
        } catch (Exception e) {
            throw new AlbumNotFoundException(500,"album inexistant !!");
        }
        
    }


    public Album addSon2Album(String idAlbum, Son son) throws AlbumNotFoundException{
        Boolean test = albumRepository.existsById(idAlbum);
        if (test) {
            var album = albumRepository.findById(idAlbum).get();
            if (album.getListSons()==null) {
                ArrayList<Son> list = new ArrayList<>();
                list.add(son);
                var nbr = album.getNbrSons();
                nbr = nbr+1;
                album.setNbrSons(nbr);
                album.setListSons(list);
            } else {
                album.getListSons().add(son);
                var nbr = album.getNbrSons();
                nbr = nbr+1;
                album.setNbrSons(nbr);
            }
            //System.out.println("album :"+album);
            return albumRepository.save(album);
        } else {
            throw new AlbumNotFoundException(500,"album inexistant !!");
        }
    }

    public Album RemoveSon2Album(String idAlbum, String idSon) throws AlbumNotFoundException, SonNotFoundException{
        //System.out.println("quatre");
        Boolean test = albumRepository.existsById(idAlbum);
        //System.out.println("cinq");
        if (test) {
            var album = albumRepository.findById(idAlbum).get();
            if (album.getListSons()==null||album.getListSons().isEmpty()) {
                //System.out.println("six");
                throw new SonNotFoundException(500, "aucun son n'a été trouvé dans cet album !!");
            } else {
                var list = album.getListSons();
                //System.out.println("sept");
                for (Son sons : list) {
                    //System.out.println("huit");
                    if (sons.getIdSon().equals(idSon)) {
                        //System.out.println("neuf");
                        album.getListSons().remove(sons);
                        var nbr = album.getNbrSons();
                        nbr = nbr-1;
                        album.setNbrSons(nbr);
                        //System.out.println("dix");
                        break;
                    } else {
                        //System.out.println("sinon");
                    }
                }
            }
            //System.out.println("album :"+album);
            sonRepository.deleteById(idSon);
            System.out.println("onze");
            return albumRepository.save(album);
        } else {
            throw new AlbumNotFoundException(500,"l'album avec pour id :"+idAlbum+" n'existe pas !!");
        }
    }

    public String deleteAlbumByid(String id) throws AlbumNotFoundException{
        Boolean test = albumRepository.existsById(id);
        if (test) {
            var album = albumRepository.findById(id).get();
            for (Son sons : album.getListSons()) {
                if (sonRepository.existsById(sons.getIdSon())) {
                    sonRepository.deleteById(sons.getIdSon());
                } else {
                    
                }
            }
            albumRepository.deleteById(id);
            return "l'album avec pour id : "+id+" a été supprimer !!";
        } else {
            throw new AlbumNotFoundException(500,"album inexistant !!");
        }       
    }

    public String deleteAllAlbum() throws AlbumNotFoundException{
        var albums = albumRepository.findAll();
    if (albums == null||albums.isEmpty()||albums.contains(null)) {
        throw new AlbumNotFoundException(500,"aucun album trouvé !!");
    } else {
        albumRepository.deleteAll();
        return "tous les sons ont été supprimés !! ";
    }
    }
}
