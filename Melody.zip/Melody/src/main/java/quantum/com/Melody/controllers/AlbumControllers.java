package quantum.com.Melody.controllers;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.var;
import quantum.com.Melody.entities.Album;

import quantum.com.Melody.exceptions.AlbumNotFoundException;

import quantum.com.Melody.exceptions.UserNotFoundException;
import quantum.com.Melody.payloads.in.AlbumPayloads;
import quantum.com.Melody.payloads.in.ModifAlbumPayload;
import quantum.com.Melody.services.AlbumServices;


@OpenAPIDefinition
@AllArgsConstructor
@RestController
@RequestMapping(value = "/album")
public class AlbumControllers {
     private final AlbumServices albumServices;

    @PostMapping(value = "/créeralbum")
    public ResponseEntity<Album> créeralbum(@Valid @RequestBody AlbumPayloads albumPayloads ) throws AlbumNotFoundException, UserNotFoundException{
        var album = albumServices.creeralbum(albumPayloads);
        return new ResponseEntity<Album>(album, HttpStatus.CREATED);
    }

    @PutMapping(value = "/modifieralbumById")
    public ResponseEntity<Album> modifieralbum(@Valid @RequestBody ModifAlbumPayload AlbumPayload,String idAlbum) throws AlbumNotFoundException{
        var Album = albumServices.modifAlbum(idAlbum, AlbumPayload);
        return new ResponseEntity<Album>(Album, HttpStatus.OK);
    }

    @PutMapping(value = "/activerdesactiveralbumById")
    public ResponseEntity<Album> actdesactcompteAlbum( String idAlbum) throws AlbumNotFoundException{
        var Album = albumServices.changerStatutAlbum(idAlbum);
        return new ResponseEntity<Album>(Album, HttpStatus.ACCEPTED);
    }

    @GetMapping(value = "/findOneAlbumById")
    public ResponseEntity<Album>findOneAlbum(String idAlbum)throws AlbumNotFoundException{
      return ResponseEntity.ok(albumServices.findOneAlbum(idAlbum));
    }

    @GetMapping(value = "/listallAlbum")
    public ResponseEntity<List<Album>> listallAlbum()throws AlbumNotFoundException{
        return ResponseEntity.ok(albumServices.listertousLesAlbums());
    }

    @DeleteMapping(value = "/supprimerAlbumById")
    public ResponseEntity<String> supprimerSon(String idAlbum) throws AlbumNotFoundException{
      var album = albumServices.deleteAlbumByid(idAlbum);
      return new ResponseEntity<String>(album,HttpStatus.OK);
    }

    @DeleteMapping(value = "/deleteAllAlbums")
    public ResponseEntity<String> deleteAllAlbums() throws AlbumNotFoundException{
        var album = albumServices.deleteAllAlbum();
        return new ResponseEntity<String>(album, HttpStatus.OK);
    }
}
