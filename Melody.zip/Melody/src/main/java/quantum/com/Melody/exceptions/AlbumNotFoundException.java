package quantum.com.Melody.exceptions;

public class AlbumNotFoundException extends Exception {
    public AlbumNotFoundException(int code, String message){
        super(message);
    }

}
