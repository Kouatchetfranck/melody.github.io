package quantum.com.Melody.config;

import quantum.com.Melody.enumerations.EnumFileType;

public class GlobalConfig {
    public static String DNSURL = "exemple.cloudfront.net";
    public final static String AUDIOS = "audios/";

    public static String getPathFileType(EnumFileType enumFileType){
            
        switch (enumFileType) {
            case AUDIOS:
                return AUDIOS;    
            default:
                return AUDIOS;
        }

    }
}
