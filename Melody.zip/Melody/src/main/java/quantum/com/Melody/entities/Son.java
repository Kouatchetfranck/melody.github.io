package quantum.com.Melody.entities;

import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import quantum.com.Melody.enumerations.EnumFileType;
import quantum.com.Melody.enumerations.StatutSon;

@Data
@AllArgsConstructor
@Builder
public class Son {
    @Id
    private String idSon;
    private String titreSon;
    private String descriptionSon;
    private LocalDateTime dateUpload;
    //private String idUploader;
    //private String nomuploader;
    private StatutSon statutSon;
    private String artiste;
    private String idAlbum;
    private String nomAlbum;
    private String urlSon;
    private EnumFileType enumFileType;
}
