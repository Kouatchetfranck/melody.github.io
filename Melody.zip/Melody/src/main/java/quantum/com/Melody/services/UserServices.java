package quantum.com.Melody.services;
import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;


import quantum.com.Melody.entities.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.var;
import quantum.com.Melody.enumerations.StatutUser;

import quantum.com.Melody.exceptions.UserNotFoundException;
import quantum.com.Melody.payloads.in.ModifUserPayload;
import quantum.com.Melody.payloads.in.UserPayload;
import quantum.com.Melody.repository.UserRepository;
@Data
@AllArgsConstructor
@Service
public class UserServices {
    private UserRepository userRepository;

    public User creerUser(UserPayload userPayload) throws UserNotFoundException{
        try {
            User user = User.builder()
            .nomUser(userPayload.getNomUser())
            .prenomUser(userPayload.getPrenomUser())
            .emailUser(userPayload.getEmailUser())
            .descriptionUser(userPayload.getDescriptionUser())
            .mdpUser(userPayload.getMdpUser())
            //.mdpUserConfirm(userPayload.getMdpUserConfirm())
            .statutUser(StatutUser.ACTIF)
            .photoProfilUser(userPayload.getPhotoProfilUser())
            .dateInscripuser(LocalDate.now())
            .phonenumber(userPayload.getPhonenumber())
            .build();
            return userRepository.save(user);
        } catch (Exception e) {
            throw new UserNotFoundException(500,"erreur lors de la création de l'utilisateur !!");
        }
    }

    public User changerStatutUser(String id) throws UserNotFoundException{
        Boolean test = userRepository.existsById(id);
        if (test) {
            User user = userRepository.findById(id).get();
            if (user.getStatutUser().equals(StatutUser.ACTIF)) {
             user.setStatutUser(StatutUser.NON_ACTIF);
        } else if (user.getStatutUser().equals(StatutUser.NON_ACTIF)) {
             user.setStatutUser(StatutUser.ACTIF);
        }
         return userRepository.save(user);
        }
        else {
            throw new UserNotFoundException(500,"l'utilisateur avec pour id : "+id+" n'existe pas !! ");
        }
    }

    public User modifUserAccount(String id, ModifUserPayload userPayload)throws UserNotFoundException{
        var test = userRepository.existsById(id);
        if (test) {
            User user = userRepository.findById(id).get();
            user.setDescriptionUser(userPayload.getDescriptionUser());
            user.setNomUser(userPayload.getNomUser());
            user.setPhotoProfilUser(userPayload.getPhotoProfilUser());
            user.setPrenomUser(userPayload.getPrenomUser());
            user.setMdpUser(userPayload.getMdpUser());
            user.setPhonenumber(userPayload.getPhonenumber());
            return userRepository.save(user);
        } else {
            throw new UserNotFoundException(500,"l'utilisateur avec pour id : "+id+" n'existe pas !! ");
        }
    }

    public List<User>listertousLesutilisateurs() throws UserNotFoundException{
         var liste = userRepository.findAll();
         if (liste.toString()=="[]") {
            throw new UserNotFoundException(500,"aucun utilisateur trouvé !!");
         } else {
            return liste;
         }
    }

    public User findOneUser(String idUser)throws UserNotFoundException{
        Boolean test = userRepository.existsById(idUser);
        if (test) {
            User user = userRepository.findById(idUser).get();
            return user;
        } else {
            throw new UserNotFoundException(500,"aucun utilisateur trouvé avec pour id : "+idUser);
        }
    }

    public boolean checkUserExistByid(String id) throws UserNotFoundException{
        try {
            return userRepository.existsById(id);
        } catch (Exception e) {
            throw new UserNotFoundException(500,"utilisateur inexistant !!");
        }
    }

    public String deleteUserByid(String id) throws UserNotFoundException{
        var test = userRepository.existsById(id);
        if (test) {
            userRepository.deleteById(id);
            return "l'utilisareur avec pour id : "+id+" a été supprimer !!";
        } else {
            throw new UserNotFoundException(500,"utilisateur inexistant !!");
        }    
    }

    public String deleteAllUser() throws UserNotFoundException{
        var users = userRepository.findAll();
        if (users == null||users.isEmpty()||users.contains(null)) {
            throw new UserNotFoundException(500,"aucun utilisateur trouvé !!");
        } else {
            userRepository.deleteAll();
            return "tous les utilisateurs ont été supprimé !! ";
        }
     }   
}


