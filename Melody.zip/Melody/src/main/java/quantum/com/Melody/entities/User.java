package quantum.com.Melody.entities;

import java.time.LocalDate;

import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import quantum.com.Melody.enumerations.StatutUser;
@Data
@AllArgsConstructor
@Builder
public class User {
    @Id
    private String idUser;
    private String nomUser;
    private String prenomUser;
    private String emailUser;
    private String mdpUser;
    //private String mdpUserConfirm;
    private StatutUser statutUser;
    private String photoProfilUser;
    private String descriptionUser;
    private LocalDate dateInscripuser;
    private String phonenumber;
}
