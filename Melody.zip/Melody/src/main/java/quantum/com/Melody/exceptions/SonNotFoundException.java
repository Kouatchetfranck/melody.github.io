package quantum.com.Melody.exceptions;

public class SonNotFoundException extends Exception {
    public SonNotFoundException(int code, String message){
        super(message);
    }
}
