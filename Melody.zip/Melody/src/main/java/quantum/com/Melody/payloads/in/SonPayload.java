package quantum.com.Melody.payloads.in;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SonPayload {

    @NotNull(message = "le titre du son est requis !!")
    @NotBlank(message= "le titre du son est requis !!")
    private String titreSon;

    private String descriptionSon;

    @NotBlank(message= "le nom d'artiste est requis !!")
    @NotNull(message = "l'artiste du son est requis !!")
    private String artiste;

    private String idAlbum;
}
