package quantum.com.Melody.payloads.in;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
@Data
@AllArgsConstructor
@Builder
public class ModifSonPayload {

    @NotNull(message = "le titre du son est requis !!")
    @NotBlank(message= "le titre du son est requis !!")
    private String titreSon;

    private String descriptionSon;
    //private LocalDateTime dateUpload;

    /*
     @NotNull(message = "l'ip de l'oploader est requis !!")
    @NotBlank(message= "l'ip de l'oploader est requis !!")
    private String idUploader;

    @NotNull(message = "le nom de l'oploader est requis !!")
    @NotBlank(message= "le nom de l'oploader est requis !!")
    private String nomuploader;
     */
    
    @NotBlank(message= "le nom d'artiste est requis !!")
    @NotNull(message = "l'artiste du son est requis !!")
    private String artiste;

    private String idAlbum;
}
