package quantum.com.Melody.entities;

import java.time.LocalDate;
import java.util.ArrayList;

import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import quantum.com.Melody.enumerations.StatutAlbum;

@Data
@AllArgsConstructor
@Builder
public class Album {
    @Id
    private String idAlbum;
    private String titreAlbum;
    private String descriptionAlbum;
    private LocalDate dateCreationAlbum;
    //private String idCreateur;
    //private String nomCreateur;
    private StatutAlbum statutAlbum;
    private String artiste;
    private ArrayList<Son> listSons;
    private int nbrSons;
}
