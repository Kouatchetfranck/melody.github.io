package quantum.com.Melody.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import quantum.com.Melody.entities.Son;

public interface SonRepository extends MongoRepository<Son, String>{ 
    /*
     public Son findByTitreSon(String titreSon);
    public Son findByArtiste(String artiste);
    public Son findByNomAlbum(String nomAlbum);
    Boolean existsByTitreSon(String titreSon);
     */
}
