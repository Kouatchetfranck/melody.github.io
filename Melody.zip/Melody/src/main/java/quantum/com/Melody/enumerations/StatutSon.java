package quantum.com.Melody.enumerations;

public enum StatutSon {
    ACTIF,
    NON_ACTIF,
    AUTRE,
}
