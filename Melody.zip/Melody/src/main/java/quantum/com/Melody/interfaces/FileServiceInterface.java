package quantum.com.Melody.interfaces;

import java.io.IOException;
import org.springframework.web.multipart.MultipartFile;

import quantum.com.Melody.exceptions.ProviderFileException;
import quantum.com.Melody.payloads.out.ResponseFileService;

public interface FileServiceInterface {
    ResponseFileService savefile(MultipartFile file, String fileType) throws IOException;
    ResponseFileService updateFile_save(MultipartFile file,String fileType,String nom) throws IOException;
    byte[] download(String filename) throws IOException;
    ResponseFileService deleteFile(String filename);
    ResponseFileService updateFile(String filename, MultipartFile file,String fileType) throws IOException, ProviderFileException;
}
