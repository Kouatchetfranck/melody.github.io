package quantum.com.Melody.payloads.in;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
@Data
@AllArgsConstructor
@Builder
public class UserPayload {

    @NotEmpty(message = "le nom d'utilisateur est requis !!")
    @NotBlank(message = "le nom d'utilisateur est requis !!")
    @NotNull(message = "le nom d'utilisateur est requis !!")
    private String nomUser;

    @NotEmpty(message = "le prenom d'utilisateur est requis !!")
    @NotNull(message = "le prenom d'utilisateur est requis !!")
    @NotBlank(message = "le prenom d'utilisateur est requis !!")
    private String prenomUser;

    @NotEmpty(message = "l'email d'utilisateur est requis !!")
    @NotNull(message = "l'email d'utilisateur est requis !!")
    @Email(message = "format d'adresse email invalide !!")
    private String emailUser;

    @NotEmpty(message = "le mot de passe d'utilisateur est requis !!")
    @NotBlank(message = "le mot de passe d'utilisateur est requis !!")
    @NotNull(message = "le mot de passe d'utilisateur est requis !!")
    private String mdpUser;
    //@NotNull(message = "veuillez confirmer le mot de passe !!")
    //private String mdpUserConfirm;
    private String photoProfilUser;
    private String descriptionUser;

    @NotNull(message = "le numéro de téléphone d'utilisateur est requis !!")
    @Email(message = "format de téléphone invalide !!")
    @Size(min=7,max=15)
    @Pattern(regexp="[0-9]")
    private String phonenumber;
  
}
