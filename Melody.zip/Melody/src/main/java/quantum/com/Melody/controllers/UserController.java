package quantum.com.Melody.controllers;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.var;
import quantum.com.Melody.entities.User;

import quantum.com.Melody.exceptions.UserNotFoundException;
import quantum.com.Melody.payloads.in.ModifUserPayload;
import quantum.com.Melody.payloads.in.UserPayload;
import quantum.com.Melody.services.UserServices;

@RestController
@AllArgsConstructor
@RequestMapping(value = "/utilisateur")
public class UserController {

    private final UserServices userServices;
    //private final UserRepository userRepository;

    @PostMapping(value = "/créercompteuser")
    public ResponseEntity<User> créerUser(@Valid @RequestBody UserPayload userPayload ) throws UserNotFoundException{
        var user = userServices.creerUser(userPayload);
        return new ResponseEntity<User>(user, HttpStatus.CREATED);
    }

    @PutMapping(value = "/modifiercompteutilisateurById")
    public ResponseEntity<User> modifiercompte(@Valid @RequestBody ModifUserPayload modifUserPayload,String idUser) throws UserNotFoundException{
        var user = userServices.modifUserAccount(idUser, modifUserPayload);
        return new ResponseEntity<User>(user, HttpStatus.ACCEPTED);
    }

    @PutMapping(value = "/activerdesactivercompteutilisateurById")
    public ResponseEntity<User> actdesactcompteuser( String idUser) throws UserNotFoundException{
        var user = userServices.changerStatutUser(idUser);
        return new ResponseEntity<User>(user, HttpStatus.OK);
    }

    @DeleteMapping(value = "/supprimercompteutilisateurById")
    public ResponseEntity<String> supprimercompteutilisateur( String idUser) throws UserNotFoundException{
        var user = userServices.deleteUserByid(idUser);
        return new ResponseEntity<String>(user, HttpStatus.OK);
    }

    @DeleteMapping(value = "/deleteAllUsers")
    public ResponseEntity<String> deleteallUsers() throws UserNotFoundException{
        var user = userServices.deleteAllUser();
        return new ResponseEntity<String>(user, HttpStatus.OK);
    }

    @GetMapping(value = "/listalluser")
    public ResponseEntity<List<User>> listalluser( )throws UserNotFoundException{
        return ResponseEntity.ok(userServices.listertousLesutilisateurs());
    }

    @GetMapping(value = "/findOneUserById")
    public ResponseEntity<User>findOneUser(String idUser) throws UserNotFoundException {
      return ResponseEntity.ok(userServices.findOneUser(idUser));
    }
}
