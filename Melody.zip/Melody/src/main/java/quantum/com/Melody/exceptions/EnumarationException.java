package quantum.com.Melody.exceptions;

public class EnumarationException extends Exception {
    public EnumarationException(int code, String message){
        super(message);
    }
}
