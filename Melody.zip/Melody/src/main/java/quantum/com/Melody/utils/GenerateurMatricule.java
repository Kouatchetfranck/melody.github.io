package quantum.com.Melody.utils;

import java.util.UUID;

public class GenerateurMatricule {
    public static String generateNameFile(){
        return UUID.randomUUID().toString();
    }
}
