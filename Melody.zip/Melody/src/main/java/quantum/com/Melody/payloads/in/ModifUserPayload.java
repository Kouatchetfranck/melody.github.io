package quantum.com.Melody.payloads.in;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
@Data
@AllArgsConstructor
@Builder
public class ModifUserPayload {

    @NotBlank(message = "le nom d'utilisateur est requis !!")
    @NotNull(message = "le nom d'utilisateur est requis !!")
    private String nomUser;

    @NotNull(message = "le prenom d'utilisateur est requis !!")
    @NotBlank(message = "le prenom d'utilisateur est requis !!")
    private String prenomUser;

    @NotNull(message = "le mot de passe d'utilisateur est requis !!")
    private String mdpUser;
    //@NotNull(message = "veuillez confirmer le mot de passe !!")
    //private String mdpUserConfirm;
    private String photoProfilUser;
    private String descriptionUser;

    @NotNull(message = "le numéro de téléphone d'utilisateur est requis !!")
    @Email(message = "format de téléphone invalide !!")
    private String phonenumber;
  
}