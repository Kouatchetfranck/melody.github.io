package quantum.com.Melody.services;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.util.IOUtils;
import org.springframework.web.multipart.MultipartFile;
import quantum.com.Melody.config.GlobalConfig;
import quantum.com.Melody.exceptions.ProviderFileException;
import quantum.com.Melody.interfaces.FileServiceInterface;
import quantum.com.Melody.payloads.out.ResponseFileService;
import quantum.com.Melody.utils.FileIoService;
import quantum.com.Melody.utils.GenerateurMatricule;
@Service
public class S3Service implements FileServiceInterface {

    @Value("${bucketName}")
    private String bucketName;
    private final AmazonS3 s3;

    public S3Service(AmazonS3 s3){
        this.s3=s3;
    }

    @Override
    public ResponseFileService savefile(MultipartFile file, String fileType) throws IOException {
        try {
            //System.out.println("etape un");
            String originalFileName = file.getOriginalFilename();
        String extension = FileIoService.getExtension(originalFileName);
        //System.out.println("etape deux");
        String uniqueName = GenerateurMatricule.generateNameFile();
        String finalFileName = uniqueName+"."+extension;
        //System.out.println("etape troix");
        File firstFile = convertMultiPartToFile(file);
        //System.out.println("nom du boucket : "+bucketName+" file type : "+fileType+" final name :"+finalFileName+" file : "+firstFile);
        PutObjectResult putObjectResult = s3.putObject(bucketName,fileType+finalFileName,firstFile);
        //System.out.println("etape quatre");
        String finalValue = GlobalConfig.DNSURL+"/"+fileType+finalFileName;
        //System.out.println("etape cinq");
        FileIoService.deleteFile(Paths.get(originalFileName));
        //System.out.println("etape six");
        return new ResponseFileService(200, finalValue, putObjectResult.getContentMd5());
        } catch (Exception e) {
            throw new UnsupportedOperationException("impossible d'enregistrer le fichier sur AWS !!");
        }  
    }

    @Override
    public ResponseFileService updateFile_save(MultipartFile file,String fileType,String nom) throws IOException {
        try {
           String originalFileName = file.getOriginalFilename();
           String finalPath = fileType+nom;
           File firstFile = convertMultiPartToFile(file);
           PutObjectResult putObjectResult = s3.putObject(bucketName, finalPath, firstFile);
           FileIoService.deleteFile(Paths.get(originalFileName));
           return new ResponseFileService(200, finalPath, putObjectResult.getContentMd5());
        } catch (Exception e) {
           throw new UnsupportedOperationException("Unimplemented method 'updatefile'");
        }   
    }

    @Override
    public byte[] download(String fileName) throws IOException {
        try {
            S3Object object = s3.getObject(bucketName, fileName);
            S3ObjectInputStream objectContent = object.getObjectContent();
            return IOUtils.toByteArray(objectContent);
        } catch (Exception e) {
            throw new UnsupportedOperationException("Unimplemented method 'download'");
        }
        
    }

    @Override
    public ResponseFileService deleteFile(String fileName) {
        try {
           s3.deleteObject(bucketName, fileName);
           return new ResponseFileService(200, "file deleted !!", "successfully");
        } catch (Exception e) {
            throw new UnsupportedOperationException("Unimplemented method 'deleteFile'");
        }
    }

    @Override
    public ResponseFileService updateFile(String url, MultipartFile file, String fileType)
            throws IOException, ProviderFileException {
        try {
            String secondvalue = url.split("d1is7hz5o3oqax.cloudfront.net")[0];
            String value = url.split("/")[-1];
            deleteFile(secondvalue);
            return updateFile_save(file, fileType, value);
        } catch (Exception e) {
            throw new UnsupportedOperationException("Unimplemented method 'updateFile'");
        }
    }
    

    private File convertMultiPartToFile(MultipartFile file) throws IOException{
        File convfile = new File(file.getOriginalFilename());
        FileOutputStream fos = new FileOutputStream(convfile);
        fos.write(file.getBytes());
        fos.close();
        return convfile;
    }
    
}
