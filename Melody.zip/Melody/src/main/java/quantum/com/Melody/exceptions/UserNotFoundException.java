package quantum.com.Melody.exceptions;

public class UserNotFoundException extends Exception {
    public UserNotFoundException(int code, String message){
        super(message);
    }

}
