package quantum.com.Melody;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MelodyApplication {

	public static void main(String[] args) {
		SpringApplication.run(MelodyApplication.class, args);
	}

}