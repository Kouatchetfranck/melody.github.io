package quantum.com.Melody.repository;
import org.springframework.data.mongodb.repository.MongoRepository;
import quantum.com.Melody.entities.Album;


public interface AlbumRepository extends MongoRepository<Album, String>{
    /*
     public Album findByTitreAlbum(String titreAlbum);
    public Album findByNomCreateur(String nomCreateur);
    public Album findByArtiste(String artiste);
     */
}
