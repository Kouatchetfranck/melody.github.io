package quantum.com.Melody.payloads.in;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
@Data
@AllArgsConstructor
@Builder
public class AlbumPayloads {
    //private String idAlbum;
    @NotNull(message = "le titre de l'album est requis !!")
    @NotBlank(message="le titre de l'album est requis !!")
    private String titreAlbum;

    private String descriptionAlbum;
    //private LocalDate dateCreationAlbum;

    @NotNull(message = "nom d'artiste requis !!")
    @NotBlank(message="nom d'artiste requis !!")
    private String artiste;
}
